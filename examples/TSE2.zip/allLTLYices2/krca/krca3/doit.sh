#!/bin/bash
cd krca3sat
sh doit.sh
cd ../krca3p1
sh doit.sh
cd ../krca3p2
sh doit.sh