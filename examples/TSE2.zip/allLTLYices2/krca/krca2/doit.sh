#!/bin/bash
cd krca2sat
sh doit.sh
cd ../krca2p1
sh doit.sh
cd ../krca2p2
sh doit.sh