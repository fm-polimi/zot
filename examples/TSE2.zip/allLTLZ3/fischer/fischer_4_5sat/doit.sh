#!/bin/bash
#Time limit in seconds:
tl=3600;
#Memory limit in MBs:
ml=10240;

run() {
 	pkill -u pourhashem mathsat; pkill -u pourhashem z3; pkill -u pourhashem nusmv; pkill -u pourhashem nuxmv; pkill -u pourhashem cvc4; pkill -u pourhashem cryptominisat; pkill -u pourhashem cryptominisat4;
	echo "$1 ...";
	if [ ! -f "$1.res" ] 
	then
		eval $2
	fi
	rm *txt;
}

file="bvzotfischer_4_5satMB30";
command="runlim -o $file.tm -r $tl -s $ml zot $file.lisp > $file.res";
run "$file" "$command";

