#!/bin/bash
cd txt8sat
sh doit.sh
cd ../txt8p1
sh doit.sh
cd ../..