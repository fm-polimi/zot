#!/bin/bash
cd txt4sat
sh doit.sh
cd ../txt4p1
sh doit.sh
cd ../..