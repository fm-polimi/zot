#!/bin/bash
cd HRCsat
sh doit.sh

cd ../HRCp1MB30
sh doit.sh

cd ../HRCp1MB60
sh doit.sh

cd ../HRCp1MB90
sh doit.sh
cd ../..